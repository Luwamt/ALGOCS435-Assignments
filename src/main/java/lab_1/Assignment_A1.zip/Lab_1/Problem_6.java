package lab_1;

import lab1.powerset.PowerSet;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class Problem_6 {
    public class SubsetSumBruteForce {
        public static boolean subsetSum(List<Integer> list, Integer z) {
            List<Set<Integer>> P = PowerSet.powerSet(list);
            //implement
            return false;
        }

        public static void main(String[] args) {
            System.out.println(subsetSum(Arrays.asList(1, 3, 9, 4, 8, 5), 21));
            System.out.println(subsetSum(Arrays.asList(1, 3, 9, 4, 8, 5), 22));
            System.out.println(subsetSum(Arrays.asList(1, 3, 9, 4, 8, 5), 31));
            System.out.println(subsetSum(Arrays.asList(1, 3, 9, 4, 8, 5), 0));
        }
    }
}