package lab_1;

public class Problem_2 {
    public static int secondSmallest(int[] arr) {
        int smallest=Integer.MAX_VALUE;
        int secondSmall=Integer.MAX_VALUE;;
        if (arr == null || arr.length < 2) {
            throw new IllegalArgumentException("Input array too small");
        }
        if(secondSmall< smallest){
            int temp= smallest;
            smallest=secondSmall;
            secondSmall=temp;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < smallest ) {
                secondSmall=smallest;
                smallest = arr[i];
            }else if (arr[i] < secondSmall)
                secondSmall=arr[i];
        }

        return secondSmall;
    }

    public static void main(String[] args) {
        System.out.println(secondSmallest(new int[]{1, 4, 2, 3}));
        System.out.println(secondSmallest(new int[]{3, 3, 4, 7}));
        System.out.println(secondSmallest(new int[]{9}));
    }
}
