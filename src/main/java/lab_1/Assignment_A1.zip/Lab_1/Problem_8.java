package lab_1;

public class Problem_8 {
    public static int smallestCommon(int x, int y) {
//implement
        if(x==0||y==0) return 0;
        int absNumber1 = Math.abs(x);
        int absNumber2 = Math.abs(y);
        int absHigherNumber = Math.max(absNumber1, absNumber2);
        int absLowerNumber = Math.min(absNumber1, absNumber2);
        int lcm = absHigherNumber;
        while (lcm % absLowerNumber != 0) {
            lcm += absHigherNumber;
        }
        return lcm;
//        if(y==0) return x;
//        return smallestCommon(y,x%y);
    }

    public static void main(String[] args) {
        System.out.println(smallestCommon(4,6));
        System.out.println(smallestCommon(3,5));
        System.out.println(smallestCommon(7,14));
    }
}
