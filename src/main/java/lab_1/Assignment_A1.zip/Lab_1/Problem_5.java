package lab_1;

public class Problem_5 {

    /**
     * 5-A
     *
     * @param args
     */

    public static boolean find(int[] arr, int z) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == z)
                return true;
        }
        return false;
    }

    /**
     * 5-B
     * Yes, we can use Binary Search tree
     * which is o(log n)  which more efficient
     * than problem A (linear Search) which is o(n).
     * @param args
     */
    public static void main(String[] args) {
        System.out.println(find(new int[]{2, 8, 3, 4}, 3));
        System.out.println(find(new int[]{2, 8, 3, 4}, 5));
        System.out.println(find(new int[]{2, 3, 4, 8}, 3));
        System.out.println(find(new int[]{2, 3, 4, 8}, 5));
    }
}